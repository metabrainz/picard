# -*- coding: utf-8 -*-
"""Dummy plugin for tests"""

PLUGIN_NAME = "Dummy plugin"
PLUGIN_AUTHOR = "Zas"
PLUGIN_DESCRIPTION = "Dummy plugin description"
PLUGIN_VERSION = "1.0"
PLUGIN_API_VERSIONS = ["2.0"]
PLUGIN_LICENSE = 'Dummy plugin license'
PLUGIN_LICENSE_URL =  'dummy.plugin.url'


class DummyPlugin:
    pass
