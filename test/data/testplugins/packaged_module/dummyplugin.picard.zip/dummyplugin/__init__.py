# -*- coding: utf-8 -*-
"""Dummy plugin for tests"""


class DummyPlugin:
    pass
